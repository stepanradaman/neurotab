<?php

$valcount = $_POST['count'];
$dir = "data/";

if(!empty($_FILES['train']))
{
	$path = "data/";
	$path = $path . basename( $_FILES['train']['name']);
	
	if(move_uploaded_file($_FILES['train']['tmp_name'], $path)) {
		echo "";
	} else{
		echo "Error train";
	}
}

if(!empty($_FILES['test']))
{
	$path = "data/";
	$path = $path . basename( $_FILES['test']['name']);
	
	if(move_uploaded_file($_FILES['test']['tmp_name'], $path)) {
		echo "";
	} else{
		echo "Error test";
	}
}

$filetrain = $dir . basename( $_FILES['train']['name']);
$filetest = $dir . basename( $_FILES['test']['name']);

require "vendor/autoload.php";
 
use Phpml\Dataset\CsvDataset;
use Phpml\Regression\LeastSquares;

$datasettrain = new CsvDataset($filetrain, $valcount, true);
$datasettest = new CsvDataset($filetest, $valcount, true);
$samplestrain = $datasettrain->getSamples();
$targetstrain = $datasettrain->getTargets();
$regression = new LeastSquares();
$regression->train($samplestrain, $targetstrain);

foreach ($datasettest->getSamples() as $sampletest) {
	$predict = $regression->predict([
		$sampletest
	]);
	echo nl2br($predict[0].PHP_EOL);
}

?>